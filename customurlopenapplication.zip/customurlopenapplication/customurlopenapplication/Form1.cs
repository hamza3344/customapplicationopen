﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using Microsoft.Win32;
using System.Windows.Forms;

namespace customurlopenapplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public void createcustomlink()
        {
            string assemblyApplication=Assembly.GetExecutingAssembly().Location;
            using(RegistryKey key=Registry.ClassesRoot.CreateSubKey("Application1"))
            {
                key.SetValue(string.Empty, "URL:CustomApplication");
                key.SetValue("URL Protocol", string.Empty);
                using(RegistryKey shellkey=key.CreateSubKey("shell"))
                    using(RegistryKey openkey=shellkey.CreateSubKey("open"))
                    using(RegistryKey coomandkey=openkey.CreateSubKey("command"))
                {
                    coomandkey.SetValue(string.Empty, $"\"{assemblyApplication}\" \"%1\"");
                }
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            createcustomlink();
        }
    }
}
